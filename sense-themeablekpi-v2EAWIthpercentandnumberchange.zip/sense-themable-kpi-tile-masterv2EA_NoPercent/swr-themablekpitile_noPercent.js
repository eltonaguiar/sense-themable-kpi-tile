define(["jquery", "underscore", "./properties", "./lib/js/extensionUtils", "text!./lib/partials/template.ng.html", "text!./lib/css/main.css", "text!./config/layouts.json"], function($, _, props, extensionUtils, ngTemplate, cssContent, layoutsText) {
    "use strict";
    extensionUtils.addStyleToHeader(cssContent, "swr-themablekpitile");
    var layouts = JSON.parse(layoutsText);
    return {
        initialProperties: {
            showTitles: !1
        },
        definition: props,
        snapshot: {
            canTakeSnapshot: !0
        },
        template: ngTemplate,
        controller: ["$scope", "$element", "$sce", function($scope, $element, $sce) {
            function getKpiComparisonColor() {
                return $scope.layout.props && $scope.layout.props.layoutMode ? $scope.get($scope.layout.props.kpiComparison > 0 ? "comparisonPositiveColor" : $scope.layout.props.kpiComparison < 0 ? "comparisonNegativeColor" : "comparisonNeutralColor") : ""
            }

            function setKpiIcon() {
                return $scope.layout.props && $scope.layout.props.layoutMode ? void($scope.kpiIcon = $sce.trustAsHtml($scope.layout.props.kpiComparison > 0 ? $scope.get("comparisonPositiveIcon") : $scope.layout.props.kpiComparison < 0 ? $scope.get("comparisonNegativeIcon") : $scope.get("comparisonNeutralIcon"))) : ""
            }
            $scope.get = function(key) {
                if (!$scope.layout.props || !$scope.layout.props.layoutMode) return "";
                var defaults = {
                    tileBackgroundColor: "#ffffff",
                    titleColor: "#333333",
                    comparisonPositiveColor: "#006600",
                    comparisonNegativeColor: "#CC0000",
                    comparisonNeutralColor: "#333333",
                    comparisonPositiveIcon: "&#9650;",
                    comparisonNegativeIcon: "&#9660;",
                    comparisonNeutralIcon: "&#9654;"
                };
                switch ($scope.layout.props.layoutMode) {
                    case "default":
                        return defaults[key];
                    case "custom":
                        return $scope.layout.props[key];
                    case "template":
                        var selectedTemplate = $scope.layout.props.layoutTemplate;
                        return layouts[selectedTemplate] ? layouts[selectedTemplate][key] : ""
                }
            }, $scope.setStyles = function() {
                var padding = 14,
                    elemHeight = $element.height() - padding;
                    $scope.tileStyle = {
                    backgroundColor: $scope.get("tileBackgroundColor")
                },
		   $scope.titleStyle = {
                    color: $scope.get("titleColor"),
                    fontSize: Math.max(elemHeight / 6, 12) + "px"
                }, $scope.kpiStyle = {
                    color: $scope.get("kpiColor"),
                    fontSize: Math.max(elemHeight / 4, 12) + "px",
                    paddingTop: Math.max(elemHeight / 10) + "px"
                }, $scope.kpiComparisonStyle = {
                    fontSize: Math.max(elemHeight / 6, 10) + "px",
                    color: getKpiComparisonColor()
                }, setKpiIcon()
            }, $scope.$watch(function() {
                return {
                    h: $element.height(),
                    w: $element.width()
                }
            }, function(newVal, oldVal) {
                !newVal || newVal.h === oldVal.h && newVal.w === oldVal.w || $scope.setStyles()
            }, !0), $scope.$watch(function() {
                return {
                    kpiComparison: $scope.layout.props ? $scope.layout.props.kpiComparison : null,
                    layoutMode: $scope.layout.props ? $scope.layout.props.layoutMode : null,
                    layoutTemplate: $scope.layout.props ? $scope.layout.props.layoutTemplate : null
                }
            }, function(newVal, oldVal) {
                !newVal || newVal.kpiComparison === oldVal.kpiComparison && newVal.layoutMode === oldVal.layoutMode && newVal.layoutTemplate === oldVal.layoutTemplate || $scope.setStyles()
            }, !0), $scope.setStyles()
        }]
    }
});